﻿namespace TH03_AppDev
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_UCBank = new System.Windows.Forms.Label();
            this.lbl_UsernameLogin = new System.Windows.Forms.Label();
            this.lbl_PasswordLogin = new System.Windows.Forms.Label();
            this.tb_UsernameLogin = new System.Windows.Forms.TextBox();
            this.tb_PasswordLogin = new System.Windows.Forms.TextBox();
            this.btn_Login = new System.Windows.Forms.Button();
            this.btn_RegisterLogin = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_UCBank
            // 
            this.lbl_UCBank.AutoSize = true;
            this.lbl_UCBank.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_UCBank.Location = new System.Drawing.Point(326, 107);
            this.lbl_UCBank.Name = "lbl_UCBank";
            this.lbl_UCBank.Size = new System.Drawing.Size(152, 37);
            this.lbl_UCBank.TabIndex = 0;
            this.lbl_UCBank.Text = "UC Bank";
            // 
            // lbl_UsernameLogin
            // 
            this.lbl_UsernameLogin.AutoSize = true;
            this.lbl_UsernameLogin.Location = new System.Drawing.Point(204, 176);
            this.lbl_UsernameLogin.Name = "lbl_UsernameLogin";
            this.lbl_UsernameLogin.Size = new System.Drawing.Size(91, 20);
            this.lbl_UsernameLogin.TabIndex = 1;
            this.lbl_UsernameLogin.Text = "Username :";
            // 
            // lbl_PasswordLogin
            // 
            this.lbl_PasswordLogin.AutoSize = true;
            this.lbl_PasswordLogin.Location = new System.Drawing.Point(204, 221);
            this.lbl_PasswordLogin.Name = "lbl_PasswordLogin";
            this.lbl_PasswordLogin.Size = new System.Drawing.Size(90, 20);
            this.lbl_PasswordLogin.TabIndex = 2;
            this.lbl_PasswordLogin.Text = "Password  :";
            // 
            // tb_UsernameLogin
            // 
            this.tb_UsernameLogin.Location = new System.Drawing.Point(306, 176);
            this.tb_UsernameLogin.Name = "tb_UsernameLogin";
            this.tb_UsernameLogin.Size = new System.Drawing.Size(188, 26);
            this.tb_UsernameLogin.TabIndex = 3;
            // 
            // tb_PasswordLogin
            // 
            this.tb_PasswordLogin.Location = new System.Drawing.Point(306, 218);
            this.tb_PasswordLogin.Name = "tb_PasswordLogin";
            this.tb_PasswordLogin.Size = new System.Drawing.Size(188, 26);
            this.tb_PasswordLogin.TabIndex = 4;
            // 
            // btn_Login
            // 
            this.btn_Login.Location = new System.Drawing.Point(333, 263);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(101, 34);
            this.btn_Login.TabIndex = 5;
            this.btn_Login.Text = "Login";
            this.btn_Login.UseVisualStyleBackColor = true;
            this.btn_Login.Click += new System.EventHandler(this.btn_Login_Click);
            // 
            // btn_RegisterLogin
            // 
            this.btn_RegisterLogin.Location = new System.Drawing.Point(333, 303);
            this.btn_RegisterLogin.Name = "btn_RegisterLogin";
            this.btn_RegisterLogin.Size = new System.Drawing.Size(101, 34);
            this.btn_RegisterLogin.TabIndex = 6;
            this.btn_RegisterLogin.Text = "Register";
            this.btn_RegisterLogin.UseVisualStyleBackColor = true;
            this.btn_RegisterLogin.Click += new System.EventHandler(this.btn_RegisterLogin_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_RegisterLogin);
            this.Controls.Add(this.btn_Login);
            this.Controls.Add(this.tb_PasswordLogin);
            this.Controls.Add(this.tb_UsernameLogin);
            this.Controls.Add(this.lbl_PasswordLogin);
            this.Controls.Add(this.lbl_UsernameLogin);
            this.Controls.Add(this.lbl_UCBank);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_UCBank;
        private System.Windows.Forms.Label lbl_UsernameLogin;
        private System.Windows.Forms.Label lbl_PasswordLogin;
        private System.Windows.Forms.TextBox tb_UsernameLogin;
        private System.Windows.Forms.TextBox tb_PasswordLogin;
        private System.Windows.Forms.Button btn_Login;
        private System.Windows.Forms.Button btn_RegisterLogin;
    }
}

