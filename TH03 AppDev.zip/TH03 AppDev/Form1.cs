﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_AppDev
{
    public partial class Form1 : Form
    {
        private DataTable dt;
        private string User;

        public Form1()
        {
            InitializeComponent();
            InitializeUsersTable();
        }

        private void InitializeUsersTable()
        {
            dt = new DataTable();
            dt.Columns.Add("Username", typeof(string));
            dt.Columns.Add("Password", typeof(string));
        }

        private void btn_RegisterLogin_Click(object sender, EventArgs e)
        {
            FormRegister registerForm = new FormRegister(dt);
            registerForm.ShowDialog();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            string username = tb_UsernameLogin.Text;
            string password = tb_PasswordLogin.Text;

            DataRow[] foundRows = dt.Select($"Username = '{username}' AND Password = '{password}'");
            if (foundRows.Length > 0)
            {
                User = username;
                BalanceForm();
            }
            else
            {
                MessageBox.Show("Username atau Password Salah");
            }
        }

        private void BalanceForm()
        {
            FormBalance formbalance = new FormBalance(User);
            formbalance.ShowDialog();
        }
    }
}
