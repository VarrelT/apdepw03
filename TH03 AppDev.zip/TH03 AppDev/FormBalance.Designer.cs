﻿namespace TH03_AppDev
{
    partial class FormBalance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Withdraw = new System.Windows.Forms.Button();
            this.btn_Deposit = new System.Windows.Forms.Button();
            this.lbl_BalanceText = new System.Windows.Forms.Label();
            this.lbl_UCBank = new System.Windows.Forms.Label();
            this.lbl_Balance = new System.Windows.Forms.Label();
            this.btn_LogOut = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Withdraw
            // 
            this.btn_Withdraw.Location = new System.Drawing.Point(323, 303);
            this.btn_Withdraw.Name = "btn_Withdraw";
            this.btn_Withdraw.Size = new System.Drawing.Size(101, 34);
            this.btn_Withdraw.TabIndex = 13;
            this.btn_Withdraw.Text = "Withdraw";
            this.btn_Withdraw.UseVisualStyleBackColor = true;
            this.btn_Withdraw.Click += new System.EventHandler(this.btn_Withdraw_Click);
            // 
            // btn_Deposit
            // 
            this.btn_Deposit.Location = new System.Drawing.Point(323, 263);
            this.btn_Deposit.Name = "btn_Deposit";
            this.btn_Deposit.Size = new System.Drawing.Size(101, 34);
            this.btn_Deposit.TabIndex = 12;
            this.btn_Deposit.Text = "Deposit";
            this.btn_Deposit.UseVisualStyleBackColor = true;
            this.btn_Deposit.Click += new System.EventHandler(this.btn_Deposit_Click);
            // 
            // lbl_BalanceText
            // 
            this.lbl_BalanceText.AutoSize = true;
            this.lbl_BalanceText.Location = new System.Drawing.Point(223, 213);
            this.lbl_BalanceText.Name = "lbl_BalanceText";
            this.lbl_BalanceText.Size = new System.Drawing.Size(91, 20);
            this.lbl_BalanceText.TabIndex = 8;
            this.lbl_BalanceText.Text = "Username :";
            // 
            // lbl_UCBank
            // 
            this.lbl_UCBank.AutoSize = true;
            this.lbl_UCBank.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_UCBank.Location = new System.Drawing.Point(299, 125);
            this.lbl_UCBank.Name = "lbl_UCBank";
            this.lbl_UCBank.Size = new System.Drawing.Size(152, 37);
            this.lbl_UCBank.TabIndex = 7;
            this.lbl_UCBank.Text = "UC Bank";
            // 
            // lbl_Balance
            // 
            this.lbl_Balance.AutoSize = true;
            this.lbl_Balance.Location = new System.Drawing.Point(319, 213);
            this.lbl_Balance.Name = "lbl_Balance";
            this.lbl_Balance.Size = new System.Drawing.Size(30, 20);
            this.lbl_Balance.TabIndex = 14;
            this.lbl_Balance.Text = "Rp";
            // 
            // btn_LogOut
            // 
            this.btn_LogOut.Location = new System.Drawing.Point(490, 303);
            this.btn_LogOut.Name = "btn_LogOut";
            this.btn_LogOut.Size = new System.Drawing.Size(98, 32);
            this.btn_LogOut.TabIndex = 15;
            this.btn_LogOut.Text = "Log Out";
            this.btn_LogOut.UseVisualStyleBackColor = true;
            this.btn_LogOut.Click += new System.EventHandler(this.btn_LogOut_Click);
            // 
            // FormBalance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_LogOut);
            this.Controls.Add(this.lbl_Balance);
            this.Controls.Add(this.btn_Withdraw);
            this.Controls.Add(this.btn_Deposit);
            this.Controls.Add(this.lbl_BalanceText);
            this.Controls.Add(this.lbl_UCBank);
            this.Name = "FormBalance";
            this.Text = "FormBalance";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Withdraw;
        private System.Windows.Forms.Button btn_Deposit;
        private System.Windows.Forms.Label lbl_BalanceText;
        private System.Windows.Forms.Label lbl_UCBank;
        private System.Windows.Forms.Label lbl_Balance;
        private System.Windows.Forms.Button btn_LogOut;
    }
}