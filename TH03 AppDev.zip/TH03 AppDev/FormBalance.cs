﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_AppDev
{
    public partial class FormBalance : Form
    {
        private string User;
        public double balance;

        public FormBalance(string User)
        {
            InitializeComponent();
            this.User = User;
            UpdateBalanceLabel();
        }

        private void UpdateBalanceLabel()
        {
            lbl_Balance.Text = $"Balance : {balance:C}";
        }
        private void btn_Deposit_Click(object sender, EventArgs e)
        {
            FormDeposit formDeposit = new FormDeposit(this);
            formDeposit.ShowDialog();
        }

        private void btn_Withdraw_Click(object sender, EventArgs e)
        {
            FormWithdraw formWithdraw = new FormWithdraw(this);
            formWithdraw.ShowDialog();
        }

        public void Deposit(double amount)
        {
            if (amount > 0)
            {
                balance += amount;
                UpdateBalanceLabel();
                MessageBox.Show("Deposit successful.");
            }
            else
            {
                MessageBox.Show("Unable to deposit the amount. Please enter a valid positive amount.");
            }
        }

        public bool Withdraw(double amount)
        {
            if (amount <= 0)
            {
                MessageBox.Show("Unable to withdraw the amount. Please enter a valid positive amount.");
                return false;
            }

            if (amount > balance)
            {
                MessageBox.Show("Insufficient balance.");
                return false;
            }

            balance -= amount;
            UpdateBalanceLabel();
            MessageBox.Show("Withdrawal successful.");
            return true;
        }

        private void btn_LogOut_Click(object sender, EventArgs e)
        {
            this.Close();
            //Form1 form1 = new Form1();
            //form1.Show();
        }
    }
}
