﻿namespace TH03_AppDev
{
    partial class FormDeposit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_LogOut = new System.Windows.Forms.Button();
            this.btn_Deposit = new System.Windows.Forms.Button();
            this.lbl_BalanceText = new System.Windows.Forms.Label();
            this.lbl_UCBank = new System.Windows.Forms.Label();
            this.tb_Deposit = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_LogOut
            // 
            this.btn_LogOut.Location = new System.Drawing.Point(519, 283);
            this.btn_LogOut.Name = "btn_LogOut";
            this.btn_LogOut.Size = new System.Drawing.Size(98, 32);
            this.btn_LogOut.TabIndex = 21;
            this.btn_LogOut.Text = "Log Out";
            this.btn_LogOut.UseVisualStyleBackColor = true;
            this.btn_LogOut.Click += new System.EventHandler(this.btn_LogOut_Click);
            // 
            // btn_Deposit
            // 
            this.btn_Deposit.Location = new System.Drawing.Point(323, 283);
            this.btn_Deposit.Name = "btn_Deposit";
            this.btn_Deposit.Size = new System.Drawing.Size(101, 34);
            this.btn_Deposit.TabIndex = 18;
            this.btn_Deposit.Text = "Deposit";
            this.btn_Deposit.UseVisualStyleBackColor = true;
            this.btn_Deposit.Click += new System.EventHandler(this.btn_Deposit_Click);
            // 
            // lbl_BalanceText
            // 
            this.lbl_BalanceText.AutoSize = true;
            this.lbl_BalanceText.Location = new System.Drawing.Point(291, 213);
            this.lbl_BalanceText.Name = "lbl_BalanceText";
            this.lbl_BalanceText.Size = new System.Drawing.Size(173, 20);
            this.lbl_BalanceText.TabIndex = 17;
            this.lbl_BalanceText.Text = "Input Deposit Amount :";
            // 
            // lbl_UCBank
            // 
            this.lbl_UCBank.AutoSize = true;
            this.lbl_UCBank.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_UCBank.Location = new System.Drawing.Point(299, 125);
            this.lbl_UCBank.Name = "lbl_UCBank";
            this.lbl_UCBank.Size = new System.Drawing.Size(152, 37);
            this.lbl_UCBank.TabIndex = 16;
            this.lbl_UCBank.Text = "UC Bank";
            // 
            // tb_Deposit
            // 
            this.tb_Deposit.Location = new System.Drawing.Point(295, 251);
            this.tb_Deposit.Name = "tb_Deposit";
            this.tb_Deposit.Size = new System.Drawing.Size(169, 26);
            this.tb_Deposit.TabIndex = 22;
            // 
            // FormDeposit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tb_Deposit);
            this.Controls.Add(this.btn_LogOut);
            this.Controls.Add(this.btn_Deposit);
            this.Controls.Add(this.lbl_BalanceText);
            this.Controls.Add(this.lbl_UCBank);
            this.Name = "FormDeposit";
            this.Text = "FormDeposit";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_LogOut;
        private System.Windows.Forms.Button btn_Deposit;
        private System.Windows.Forms.Label lbl_BalanceText;
        private System.Windows.Forms.Label lbl_UCBank;
        private System.Windows.Forms.TextBox tb_Deposit;
    }
}