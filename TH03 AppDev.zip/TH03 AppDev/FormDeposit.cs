﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_AppDev
{
    public partial class FormDeposit : Form
    {
        private FormBalance formbalance;
        public FormDeposit(FormBalance formbalance)
        {
            InitializeComponent();
            this.formbalance = formbalance;
        }

        private void btn_Deposit_Click(object sender, EventArgs e)
        {
            double amount;
            if (double.TryParse(tb_Deposit.Text, out amount))
            {
                formbalance.Deposit(amount);
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid amount. Please enter a valid number.");
            }
        }

        private void btn_LogOut_Click(object sender, EventArgs e)
        {
            this.Close();
            //Form1 form1 = new Form1();
            //form1.Show();
        }
    }
}
