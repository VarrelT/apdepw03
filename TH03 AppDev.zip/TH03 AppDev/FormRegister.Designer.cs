﻿namespace TH03_AppDev
{
    partial class FormRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_RegisterRegis = new System.Windows.Forms.Button();
            this.tb_PasswordRegister = new System.Windows.Forms.TextBox();
            this.tb_UsernameRegister = new System.Windows.Forms.TextBox();
            this.lbl_PasswordLogin = new System.Windows.Forms.Label();
            this.lbl_UsernameLogin = new System.Windows.Forms.Label();
            this.lbl_UCBank = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_RegisterRegis
            // 
            this.btn_RegisterRegis.Location = new System.Drawing.Point(350, 274);
            this.btn_RegisterRegis.Name = "btn_RegisterRegis";
            this.btn_RegisterRegis.Size = new System.Drawing.Size(101, 34);
            this.btn_RegisterRegis.TabIndex = 13;
            this.btn_RegisterRegis.Text = "Register";
            this.btn_RegisterRegis.UseVisualStyleBackColor = true;
            this.btn_RegisterRegis.Click += new System.EventHandler(this.btn_RegisterRegis_Click);
            // 
            // tb_PasswordRegister
            // 
            this.tb_PasswordRegister.Location = new System.Drawing.Point(306, 219);
            this.tb_PasswordRegister.Name = "tb_PasswordRegister";
            this.tb_PasswordRegister.Size = new System.Drawing.Size(188, 26);
            this.tb_PasswordRegister.TabIndex = 11;
            // 
            // tb_UsernameRegister
            // 
            this.tb_UsernameRegister.Location = new System.Drawing.Point(306, 177);
            this.tb_UsernameRegister.Name = "tb_UsernameRegister";
            this.tb_UsernameRegister.Size = new System.Drawing.Size(188, 26);
            this.tb_UsernameRegister.TabIndex = 10;
            // 
            // lbl_PasswordLogin
            // 
            this.lbl_PasswordLogin.AutoSize = true;
            this.lbl_PasswordLogin.Location = new System.Drawing.Point(204, 222);
            this.lbl_PasswordLogin.Name = "lbl_PasswordLogin";
            this.lbl_PasswordLogin.Size = new System.Drawing.Size(90, 20);
            this.lbl_PasswordLogin.TabIndex = 9;
            this.lbl_PasswordLogin.Text = "Password  :";
            // 
            // lbl_UsernameLogin
            // 
            this.lbl_UsernameLogin.AutoSize = true;
            this.lbl_UsernameLogin.Location = new System.Drawing.Point(204, 177);
            this.lbl_UsernameLogin.Name = "lbl_UsernameLogin";
            this.lbl_UsernameLogin.Size = new System.Drawing.Size(91, 20);
            this.lbl_UsernameLogin.TabIndex = 8;
            this.lbl_UsernameLogin.Text = "Username :";
            // 
            // lbl_UCBank
            // 
            this.lbl_UCBank.AutoSize = true;
            this.lbl_UCBank.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_UCBank.Location = new System.Drawing.Point(326, 108);
            this.lbl_UCBank.Name = "lbl_UCBank";
            this.lbl_UCBank.Size = new System.Drawing.Size(152, 37);
            this.lbl_UCBank.TabIndex = 7;
            this.lbl_UCBank.Text = "UC Bank";
            // 
            // FormRegister
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_RegisterRegis);
            this.Controls.Add(this.tb_PasswordRegister);
            this.Controls.Add(this.tb_UsernameRegister);
            this.Controls.Add(this.lbl_PasswordLogin);
            this.Controls.Add(this.lbl_UsernameLogin);
            this.Controls.Add(this.lbl_UCBank);
            this.Name = "FormRegister";
            this.Text = "FormRegister";
            this.Load += new System.EventHandler(this.FormRegister_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_RegisterRegis;
        private System.Windows.Forms.TextBox tb_PasswordRegister;
        private System.Windows.Forms.TextBox tb_UsernameRegister;
        private System.Windows.Forms.Label lbl_PasswordLogin;
        private System.Windows.Forms.Label lbl_UsernameLogin;
        private System.Windows.Forms.Label lbl_UCBank;
    }
}