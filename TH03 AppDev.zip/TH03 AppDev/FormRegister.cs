﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_AppDev
{
    public partial class FormRegister : Form
    {
        private DataTable dt;
        public FormRegister(DataTable dt)
        {
            InitializeComponent();
            this.dt = dt;
        }

        private void FormRegister_Load(object sender, EventArgs e)
        {
            
        }
        
        private void btn_RegisterRegis_Click(object sender, EventArgs e)
        {
            string username = tb_UsernameRegister.Text;
            string password = tb_PasswordRegister.Text;

            if (dt.Select($"Username = '{username}'").Any())
            {
                MessageBox.Show("Username Has Been Used");
                return;
            }
            dt.Rows.Add(username, password);
            MessageBox.Show("Register Successful");
            this.Close();
            //Form1 form1 = new Form1();
            //form1.Show();
        }
    }
}
