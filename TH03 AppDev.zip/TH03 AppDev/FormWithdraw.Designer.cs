﻿namespace TH03_AppDev
{
    partial class FormWithdraw
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_Withdraw = new System.Windows.Forms.TextBox();
            this.btn_LogOut = new System.Windows.Forms.Button();
            this.btn_Withdraw = new System.Windows.Forms.Button();
            this.lbl_InputWithdraw = new System.Windows.Forms.Label();
            this.lbl_UCBank = new System.Windows.Forms.Label();
            this.lbl_BalanceText = new System.Windows.Forms.Label();
            this.lbl_BalanceWithdraw = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tb_Withdraw
            // 
            this.tb_Withdraw.Location = new System.Drawing.Point(296, 252);
            this.tb_Withdraw.Name = "tb_Withdraw";
            this.tb_Withdraw.Size = new System.Drawing.Size(169, 26);
            this.tb_Withdraw.TabIndex = 27;
            // 
            // btn_LogOut
            // 
            this.btn_LogOut.Location = new System.Drawing.Point(520, 284);
            this.btn_LogOut.Name = "btn_LogOut";
            this.btn_LogOut.Size = new System.Drawing.Size(98, 32);
            this.btn_LogOut.TabIndex = 26;
            this.btn_LogOut.Text = "Log Out";
            this.btn_LogOut.UseVisualStyleBackColor = true;
            this.btn_LogOut.Click += new System.EventHandler(this.btn_LogOut_Click);
            // 
            // btn_Withdraw
            // 
            this.btn_Withdraw.Location = new System.Drawing.Point(324, 284);
            this.btn_Withdraw.Name = "btn_Withdraw";
            this.btn_Withdraw.Size = new System.Drawing.Size(101, 34);
            this.btn_Withdraw.TabIndex = 25;
            this.btn_Withdraw.Text = "Withdraw";
            this.btn_Withdraw.UseVisualStyleBackColor = true;
            this.btn_Withdraw.Click += new System.EventHandler(this.btn_Withdraw_Click);
            // 
            // lbl_InputWithdraw
            // 
            this.lbl_InputWithdraw.AutoSize = true;
            this.lbl_InputWithdraw.Location = new System.Drawing.Point(292, 214);
            this.lbl_InputWithdraw.Name = "lbl_InputWithdraw";
            this.lbl_InputWithdraw.Size = new System.Drawing.Size(196, 20);
            this.lbl_InputWithdraw.TabIndex = 24;
            this.lbl_InputWithdraw.Text = "Input Withdrawal Amount :";
            // 
            // lbl_UCBank
            // 
            this.lbl_UCBank.AutoSize = true;
            this.lbl_UCBank.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_UCBank.Location = new System.Drawing.Point(300, 126);
            this.lbl_UCBank.Name = "lbl_UCBank";
            this.lbl_UCBank.Size = new System.Drawing.Size(152, 37);
            this.lbl_UCBank.TabIndex = 23;
            this.lbl_UCBank.Text = "UC Bank";
            // 
            // lbl_BalanceText
            // 
            this.lbl_BalanceText.AutoSize = true;
            this.lbl_BalanceText.Location = new System.Drawing.Point(274, 182);
            this.lbl_BalanceText.Name = "lbl_BalanceText";
            this.lbl_BalanceText.Size = new System.Drawing.Size(79, 20);
            this.lbl_BalanceText.TabIndex = 28;
            this.lbl_BalanceText.Text = "Balance : ";
            // 
            // lbl_BalanceWithdraw
            // 
            this.lbl_BalanceWithdraw.AutoSize = true;
            this.lbl_BalanceWithdraw.Location = new System.Drawing.Point(359, 182);
            this.lbl_BalanceWithdraw.Name = "lbl_BalanceWithdraw";
            this.lbl_BalanceWithdraw.Size = new System.Drawing.Size(34, 20);
            this.lbl_BalanceWithdraw.TabIndex = 29;
            this.lbl_BalanceWithdraw.Text = "Rp ";
            // 
            // FormWithdraw
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbl_BalanceWithdraw);
            this.Controls.Add(this.lbl_BalanceText);
            this.Controls.Add(this.tb_Withdraw);
            this.Controls.Add(this.btn_LogOut);
            this.Controls.Add(this.btn_Withdraw);
            this.Controls.Add(this.lbl_InputWithdraw);
            this.Controls.Add(this.lbl_UCBank);
            this.Name = "FormWithdraw";
            this.Text = "FormWithdraw";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_Withdraw;
        private System.Windows.Forms.Button btn_LogOut;
        private System.Windows.Forms.Button btn_Withdraw;
        private System.Windows.Forms.Label lbl_InputWithdraw;
        private System.Windows.Forms.Label lbl_UCBank;
        private System.Windows.Forms.Label lbl_BalanceText;
        private System.Windows.Forms.Label lbl_BalanceWithdraw;
    }
}