﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_AppDev
{
    public partial class FormWithdraw : Form
    {
        private FormBalance formbalance;
        public FormWithdraw(FormBalance formbalance)
        {
            InitializeComponent();
            this.formbalance = formbalance;
            UpdateBalanceLabel();
        }

        private void UpdateBalanceLabel()
        {
            lbl_BalanceWithdraw.Text = $"Current Balance: {formbalance.balance:C}";
        }

        private void btn_Withdraw_Click(object sender, EventArgs e)
        {
            double amount;
            if (double.TryParse(tb_Withdraw.Text, out amount))
            {
                if (formbalance.Withdraw(amount))
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid amount. Please enter a valid number.");
            }
        }

        private void btn_LogOut_Click(object sender, EventArgs e)
        {
            this.Close();
            //Form1 form1 = new Form1();
            //form1.Show();
        }
    }
}
